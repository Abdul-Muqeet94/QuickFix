
(function () {
  var app = angular.module("calendarModule", ['ngRoute']);

  app.controller("calendarController", function ($scope, $http, $rootScope, close, ModalService) {



  });

  ////


})();
