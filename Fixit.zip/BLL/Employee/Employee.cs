using Fixit.Models;
using Fixit.Request_and_Responses;
using Fixit.Request_and_Responses.Employee;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace Fixit.BLL
{
    public class Employee
    {
         private readonly FixitContext _db;
        public Employee(FixitContext context)
        {
            _db=context;
        }
        public BaseResponse createEmployee(EmployeeReq req)
        {
            BaseResponse toReturn=new BaseResponse();
            var db=_db;
            var employeeType= db.services.Where(c=>c.id==req.typeId && c.enable==true).FirstOrDefault();
            db.employee.Add(
                new Models.Employee{
                    name=req.name,
                    email=req.email,
                    code=req.code,
                    contactNo=req.contactNo,
                    emiratesId=req.emiratesId,
                    nationality=req.nationality,
                    status=req.status,
                    type=(employeeType!=null)?employeeType:new Fixit.Models.Services(),
                    enable=true
                }
            );
            if(db.SaveChanges()>0)
            {
                toReturn.developerMessage="Employee Added Successfully";
                toReturn.status=1;
            }
            else
            {
                toReturn.developerMessage="unable to add employee";
                toReturn.status=-1;
            }
            return toReturn;
        }

        public BaseResponse editEmployee(EmployeeReq req)
        {
            BaseResponse toReturn=new BaseResponse();
            var db=_db;
            var employee=db.employee.Where(c=>c.id==req.id && c.enable==true).FirstOrDefault();
            var employeeType=db.services.Where(c=>c.id==req.typeId && c.enable==true).FirstOrDefault();
            employee.email = req.email;
            employee.name = req.name;
            employee.code = req.code;
            employee.contactNo = req.contactNo;
            employee.emiratesId = req.emiratesId;
            employee.nationality = req.nationality;
            employee.status = req.status;
            employee.type=(employeeType!=null)?employeeType:employee.type;
            if(db.SaveChanges()>0)
            {
                toReturn.developerMessage= "Employee edit successfully";
                toReturn.status=1;
            }
            else
            {
                toReturn.developerMessage="unable to edit employee ";
                toReturn.status=-1;
            }
            return toReturn;
        }

        public List<EmployeeRes> getEmployee (int id)
        {
            List< EmployeeRes> toReturn=new List<EmployeeRes>();
            List<Models.Employee> getEmp=new List<Models.Employee>();
            var db=_db;
            if(id==0)
            {
                 getEmp=db.employee.Where(c=>c.enable==true).Include(c=>c.type).ToList();
                 
            }
            else
            {
                getEmp=db.employee.Where(c=>c.id==id && c.enable==true).Include(m=>m.type).ToList();
            }
            for (int i=0;i<getEmp.Count;i++)
            {
                EmployeeRes res=new EmployeeRes();
                res.id=getEmp[i].id;
                res.name=getEmp[i].name;
                res.email=getEmp[i].email;
                res.status=getEmp[i].status;
                res.code=getEmp[i].code;
                res.contactNo=getEmp[i].contactNo;
                res.emiratesId=getEmp[i].emiratesId;
                res.nationality=getEmp[i].nationality;
                res.enable=getEmp[i].enable;
                res.type=getEmp[i].type.name;
                toReturn.Add(res) ;
                
            }
            return toReturn; 
        }
        
        public BaseResponse deleteemployee (int id)
        {
            BaseResponse toReturn =new BaseResponse ();
            var db=_db;
            var employee=db.employee.Find(id);
            employee.enable=false;
            if(db.SaveChanges()>0)
            {
                toReturn.developerMessage="employee deleted successfully";
                toReturn.status=1;
            }
            else
            {
                toReturn.developerMessage="unable to delte employee";
                toReturn.status=-1;
            }
            return toReturn;
        }
    }
}