using Fixit.Models;
using Fixit.Request_and_Responses;
using System.Collections.Generic;
using System.Linq;
using Fixit.Request_and_Responses.Task;
using Microsoft.EntityFrameworkCore;
using Fixit.Request_and_Responses.Service;
using Fixit.Request_and_Responses.Feature;
using Fixit.Request_and_Responses.Employee;

namespace Fixit.BLL
{
    public class Task
    {
        private readonly FixitContext _db;
        public Task(FixitContext context)
        {
            _db = context;
        }
        public BaseResponse createTask(TaskReq req)
        {
            BaseResponse toReturn = new BaseResponse();
            var db = _db;
            List<TaskHasEmployee> serviceMapping = new List<TaskHasEmployee>();
            List<SelectedFeatures> featuresMapping =new List<SelectedFeatures>();
            
              Models.Task task=  new Models.Task();
                
                    task.landmark = req.landmark;
                    task.location = req.location;
                    task.house_no = req.house_no;
                    task.customer_contact = req.customer_contact;
                    task.date = req.date;
                    task.enable = true;
                    task.callUpCharges=200;
                    task.name=req.name;
                    task.paymentStatus=req.paymentStatus;
                
            foreach (var entity in req.selected_services)
            {
                var service =db.services.Find(entity.id);
                TaskHasEmployee _serviceMapping =new TaskHasEmployee();
                _serviceMapping.selectedservice=service;
                _serviceMapping.selected_shift=db.shifts.Find(req.selected_shift);
                _serviceMapping.enable=true;
                _serviceMapping.task=task;
                foreach(var feature in entity.features)
                {
                    var _features=db.Features.Find(feature);
                    featuresMapping.Add(new SelectedFeatures {
                        features=_features,
                        taskhasemployee=_serviceMapping,
                        enable=true
                    });
                }
                _serviceMapping.selected_features.AddRange(featuresMapping);
                serviceMapping.Add(_serviceMapping);
            }
            
            task.services_employee=serviceMapping;
            db.selected_features.AddRange(featuresMapping);
            db.task_has_employee.AddRange(serviceMapping);
            db.tasks.Add(task);
           
            
            
            if (db.SaveChanges() > 0)
            {
                toReturn.developerMessage = "Task Assigned Successfully";
                toReturn.status = 1;
            }
            else
            {
                toReturn.developerMessage = "unable to Assign Task";
                toReturn.status = -1;
            }
            return toReturn;
        }

        public BaseResponse editTask(TaskReq req)
        {
            BaseResponse toReturn = new BaseResponse();

            var db = _db;

            var task = db.tasks.Where(c => c.id == req.id && c.enable == true).FirstOrDefault();

            List<Features> features = new List<Features>();

            foreach (var entity in req.selected_services)
            {
                features.Add(_db.Features.Find(entity));
            }

            task.landmark = req.landmark;
            task.location = req.location;
            task.house_no = req.house_no;
            task.customer_contact = req.customer_contact;
       
            task.date = req.date;

            if (db.SaveChanges() > 0)
            {
                toReturn.developerMessage = "Task edited Successfully";
                toReturn.status = 1;
            }
            else
            {
                toReturn.developerMessage = "Unable to edit Task";
                toReturn.status = -1;
            }
            return toReturn;
        }

        public List<TaskRes> getTask(int id)
        {
            List<TaskRes> toReturn = new List<TaskRes>();
            List<Models.Task> getTsk = new List<Models.Task>();
            var db = _db;
            if (id == 0)
            {
                getTsk = db.tasks.Where(c => c.enable == true)
                .Include(c=>c.services_employee)
                .ThenInclude(m=>m.selectedservice)
                .Include(m=>m.services_employee)
                .ThenInclude(m=>m.selected_features)
                .ThenInclude(m=>m.features)
                .Include(m=>m.services_employee)
                .ThenInclude(m=>m.selected_shift)
                .Include(m=>m.services_employee)
                .ThenInclude(m=>m.employee)
                .ToList();

            }
            else
            {
                getTsk = db.tasks.Where(c => c.id == id && c.enable == true)
                .Include(c=>c.services_employee)
                .ThenInclude(m=>m.selectedservice)
                .Include(m=>m.services_employee)
                .ThenInclude(m=>m.selected_features)
                .ThenInclude(m=>m.features)
                .Include(m=>m.services_employee)
                .ThenInclude(m=>m.selected_shift)
                .Include(m=>m.services_employee)
                .ThenInclude(m=>m.employee)
                .ToList();
            }
            for (int i = 0; i < getTsk.Count; i++)
            {
                TaskRes res = new TaskRes();
                List<ServiceRes> services=new List<ServiceRes>();
                res.id = getTsk[i].id;
                string[] words= getTsk[i].location.Split(',');
                res.lat=words[0];
                res.longg=words[1];
                res.landmark = getTsk[i].landmark;
                res.house_no = getTsk[i].house_no;
                res.customer_contact = getTsk[i].customer_contact;
                res.date = getTsk[i].date.ToString();
                res.name=getTsk[i].name;
                res.callUpCharges=getTsk[i].callUpCharges;
                res.paymentStatus=(getTsk[i].paymentStatus==0)?"Un Paid":"Paid";
                foreach(var entity in getTsk[i].services_employee)
                {
                    ServiceRes service=new ServiceRes();
                    service.name=entity.selectedservice.name;
                    service.description=entity.selectedservice.description;
                    res.selected_shift=entity.selected_shift;
                    foreach(var feature in entity.selected_features)
                    {
                        FeatureRes features=new FeatureRes();
                        features.id=feature.features.id;
                        features.name=feature.features.name;
                        features.description=feature.features.description;
                        service.feature.Add(features);
                    }
                    res.selected_shift=entity.selected_shift;
                    if(entity.employee!=null)
                    {
                        res.assigned_employee.Add(entity.employee.name);
                    }
                    
                   res.selected_features.Add(service);
                    
                }
                toReturn.Add(res);

            }
            return toReturn;
        }

 public List<TaskAssignRes> getForViewTask(int id)
        {
            List<TaskAssignRes> toReturn = new List<TaskAssignRes>();
            List<Models.Task> getTsk = new List<Models.Task>();
            var db = _db;
            if (id == 0)
            {
                getTsk = db.tasks.Where(c => c.enable == true)
                .Include(c=>c.services_employee)
                .ThenInclude(m=>m.selectedservice)
                .Include(m=>m.services_employee)
                .ThenInclude(m=>m.selected_features)
                .ThenInclude(m=>m.features)
                .Include(m=>m.services_employee)
                .ThenInclude(m=>m.selected_shift)
                .ToList();

            }
            else
            {
                getTsk = db.tasks.Where(c => c.id == id && c.enable == true)
                .Include(c=>c.services_employee)
                .ThenInclude(m=>m.selectedservice)
                .Include(m=>m.services_employee)
                .ThenInclude(m=>m.selected_features)
                .ThenInclude(m=>m.features)
                .Include(m=>m.services_employee)
                .ThenInclude(m=>m.selected_shift)
                .ToList();
            }
            for (int i = 0; i < getTsk.Count; i++)
            {
                TaskAssignRes res = new TaskAssignRes();
                List<ViewServiceRes> services=new List<ViewServiceRes>();
                res.id = getTsk[i].id;
                string[] words= getTsk[i].location.Split(',');
                res.lat=words[0];
                res.longg=words[1];
                res.landmark = getTsk[i].landmark;
                res.house_no = getTsk[i].house_no;
                res.customer_contact = getTsk[i].customer_contact;
                res.date = getTsk[i].date.ToString();
                res.name=getTsk[i].name;
                res.callUpCharges=getTsk[i].callUpCharges;
                res.paymentStatus=(getTsk[i].paymentStatus==0)?"Un Paid":"Paid";
                foreach(var entity in getTsk[i].services_employee)
                {
                    ViewServiceRes service=new ViewServiceRes();
                    service.name=entity.selectedservice.name;
                    service.description=entity.selectedservice.description;
                    res.selected_shift=entity.selected_shift;
                    foreach(var feature in entity.selected_features)
                    {
                        FeatureRes features=new FeatureRes();
                        features.id=feature.features.id;
                        features.name=feature.features.name;
                        features.description=feature.features.description;
                        service.feature.Add(features);
                    }
                    var employeesList=db.employee.Where(m=>m.enable==true && m.type.id==entity.selectedservice.id).Include(m=>m.type);
                    foreach(var employee  in employeesList)
                    {
                        EmployeeRes employeeRes=new EmployeeRes();
                        employeeRes.id=employee.id;
                        employeeRes.name=employee.name;
                        service.assigned_employee.Add(employeeRes);
                    }
                    res.selected_shift=entity.selected_shift;
                    res.selected_features.Add(service);
                    
                    
                }
                toReturn.Add(res);
            }
            return toReturn;
        }
        public BaseResponse deletetask(int id)
        {
            BaseResponse toReturn = new BaseResponse();
            var db = _db;
            var task = db.tasks.Find(id);
            task.enable = false;
            if (db.SaveChanges() > 0)
            {
                toReturn.developerMessage = "Task deletetion successfully";
                toReturn.status = 1;
            }
            else
            {
                toReturn.developerMessage = "Unable to delete Task";
                toReturn.status = -1;
            }
            return toReturn;
        }

        public BaseResponse assigntask(AssignReq req)
        {
            BaseResponse toReturn = new BaseResponse();
            var db = _db;
            var task = db.tasks.Where(m=>m.id==req.task_id).Include(m=>m.services_employee).ThenInclude(m=>m.selectedservice).FirstOrDefault();
            foreach (var entity in req.service_employee)
            {
                var emp = db.employee.Find(entity.employeeId);
                

                task.services_employee.Where(m=>m.selectedserviceid==entity.serviceId)
                .FirstOrDefault().employee=emp;
            }

            if (db.SaveChanges() > 0)
            {
                toReturn.developerMessage = "Task Assigned successfully";
                toReturn.status = 1;
            }
            else
            {
                toReturn.developerMessage = "Unable to Assign Task";
                toReturn.status = -1;
            }
            return toReturn;
        }

        //
        public BaseResponse updateAssignedTask(AssignReq req)
        {

            // correct some logic here
            BaseResponse toReturn = new BaseResponse();
            var db = _db;
            List<TaskHasEmployee> list = new List<TaskHasEmployee>();


            //
            foreach (var entity in req.service_employee)
            {

                if (_db.task_has_employee.Any(o => o.task.id == req.task_id ))
                {
                    list.Add(_db.task_has_employee.Where(o => o.task.id == req.task_id).FirstOrDefault());
                }
                else
                {
                    var taskhasEmployee = new Models.TaskHasEmployee
                    {
                        employee = _db.employee.Find(entity),
                        task = _db.tasks.Find(req.task_id)
                    };

                    db.task_has_employee.Add(taskhasEmployee);
                    list.Add(taskhasEmployee);
                }
            }

            if (db.SaveChanges() > 0)
            {
                toReturn.developerMessage = "Task Assign Updated successfully";
                toReturn.status = 1;
            }
            else
            {
                toReturn.developerMessage = "Unable to Update Assigned Task";
                toReturn.status = -1;
            }
            return toReturn;
        }
        //

    }
}