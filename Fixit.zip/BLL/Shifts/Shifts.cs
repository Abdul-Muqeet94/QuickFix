using Fixit.Models;
using System.Collections.Generic;
using System.Linq;
using Fixit.Request_and_Responses;
using Fixit.Request_and_Responses.Shifts;
using System;

namespace Fixit.BLL
{
    public static class MyDateTimeUtil
{
    public static DateTime CreateDateFromTime(int year, int month, int day, DateTime time)
    {
        return new DateTime(year, month, day, time.Hour, time.Minute, 0);
    }
}
        public class Shifts
    {
         private readonly FixitContext _db;
        public Shifts(FixitContext context)
        {
            _db=context;
        }
        public BaseResponse createShift(ShiftReq req)
        {
           
           
 req.sTime = MyDateTimeUtil.CreateDateFromTime(2000, 01, 01, req.sTime);
req.eTime = MyDateTimeUtil.CreateDateFromTime(2000, 01, 01, req.eTime);

           
            BaseResponse toReturn=new BaseResponse();
            var db=_db;

if(db.shifts.Any(o=>o.day==req.day&&o.eDate==req.eDate&&o.sDate==req.sDate&&o.sTime==req.eTime&&o.enable==true))
{
    toReturn.developerMessage="Shift With The Desired values is Already presnet";
                toReturn.status=1;
                return toReturn;
}
var shift = new Models.Shifts();
                    shift.name = req.name;
                    shift.enable=req.enable;
                     shift.eTime  = req.eTime;
                      shift.sTime =req.sTime; 
                      shift.eDate = req.eDate;
                      shift.sDate= req.sDate;
                      shift.day = req.day;

            db.shifts.Add(shift);
            if(db.SaveChanges()>0)
            {
                toReturn.developerMessage="Shift Added Successfully";
                toReturn.status=1;
                toReturn.id=shift.id;
            }
            else
            {
                toReturn.developerMessage="unable to add Shift";
                toReturn.status=-1;
            }
            return toReturn;
        }

        public BaseResponse editShift(ShiftReq req)
        {
            BaseResponse toReturn=new BaseResponse();
            var db=_db;
            var shift=db.shifts.Where(c=>c.id==req.id && c.enable==true).FirstOrDefault();
            shift.name=req.name;
            shift.eTime =req.eTime;
            shift.sTime = req.sTime;
            if(db.SaveChanges()>0)
            {
                toReturn.developerMessage= "Shift edit successfully";
                toReturn.status=1;
            }
            else
            {
                toReturn.developerMessage="unable to edit Shift";
                toReturn.status=-1;
            }
            return toReturn;
        }

        public List<ShiftRes> getShift (int id)
        {
            List<ShiftRes> toReturn=new List<ShiftRes>();
            List<Models.Shifts> getShf=new List<Models.Shifts>();
            var db=_db;
            if(id==0)
            {
                 getShf=db.shifts.Where(c=>c.enable==true).ToList();
                 
            }
           else if(id==-1){
               getShf = db.shifts.OrderByDescending(p => p.id).ToList();
               var model=getShf[0];
               getShf.Clear();
               getShf.Add(model);
           }
            else
            {
                getShf=db.shifts.Where(c=>c.id==id && c.enable==true).ToList();
            }
            for (int i=0;i<getShf.Count;i++)
            {
                ShiftRes res=new ShiftRes();
                res.id=getShf[i].id;
                res.name=getShf[i].name;
                res.sTime=getShf[i].sTime.ToString();
                res.eTime=getShf[i].eTime.ToString();
                res.sDate=getShf[i].sDate.ToString("yyyy-MM-dd");
                res.eDate=getShf[i].eDate.ToString("yyyy-MM-dd");
                res.enable=getShf[i].enable;
                res.day=getShf[i].day;
                toReturn.Add(res);
                
            }
            return toReturn; 
        }
        
        public BaseResponse deleteShift (int id)
        {
            BaseResponse toReturn =new BaseResponse ();
            var db=_db;
            var shift=db.shifts.Find(id);
            shift.enable=false;
            if(db.SaveChanges()>0)
            {
                toReturn.developerMessage="Shift  delete success";
                toReturn.status=1;
            }
            else
            {
                toReturn.developerMessage="unable to delete shift";
                toReturn.status=-1;
            }
            return toReturn;
        }
    }
}