namespace Fixit.Models
{
    public class PageHeading:Identity
    {
        public string heading {get;set;}
        public string description {get;set;}
    }
}