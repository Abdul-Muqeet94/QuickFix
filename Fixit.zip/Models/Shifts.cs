using System;

namespace Fixit.Models
{
    public class Shifts:Identity
    {
        public string name {get;set;}
        public DateTime sTime {get;set;}
        public DateTime eTime {get;set;}

        public DateTime sDate {get;set;}
        public DateTime eDate {get;set;}

      public int day {get;set;}
        
    }
}