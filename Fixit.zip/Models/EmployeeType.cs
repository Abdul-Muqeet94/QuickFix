namespace Fixit.Models
{
    public class EmployeeType:Identity
    {
        public string name {get;set;}
    }
}