using System.Collections.Generic;


namespace Fixit.Models
{
    public class CmsPages:Identity
    {
        public CmsPages()
        {
            page_heading =new List<PageHeading>();
        }
        public string page_name {get;set;}
        public virtual List<PageHeading> page_heading {get;set;}
    }
}