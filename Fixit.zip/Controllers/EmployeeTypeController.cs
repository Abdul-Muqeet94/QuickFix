using System.Collections.Generic;
using Fixit.Models;
using Fixit.Request_and_Responses;
using Fixit.Request_and_Responses.EmployeeType;
using Microsoft.AspNetCore.Mvc;

namespace Fixit.Controllers
{
    public class EmployeeTypeController:BaseController
    {
         public EmployeeTypeController(FixitContext context):base(context)
        {

        }

        [Route("api/employeetype/create"), HttpPost]
        public BaseResponse addEmployee ([FromBody] EmployeeTypeReq employee)
        {
            return new BLL.EmployeeType(_db).createEmployeeType(employee);
        }
        [Route("api/employeetype/edit"), HttpPost]
        public BaseResponse editEmployee ([FromBody] EmployeeTypeReq employee)
        {
            return new  BLL.EmployeeType(_db).editEmployeeType(employee);
        }
         [Route("api/employeetype/view"), HttpPost]
        public List<EmployeeTypeRes> viewEmployee ([FromBody] int id)
        {
            return new  BLL.EmployeeType(_db).getEmployeeType(id);
        }
        [Route("api/employeetype/delete"), HttpPost]
        public BaseResponse deleteEmployee ([FromBody] int id)
        {
            return new BLL.EmployeeType(_db).deleteEmployeeType(id);
        }
    }
}