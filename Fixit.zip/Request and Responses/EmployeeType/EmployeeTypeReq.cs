namespace Fixit.Request_and_Responses.EmployeeType
{
    public class EmployeeTypeReq
    {
        public int id {get;set;}
        public string name {get;set;}
    }
}