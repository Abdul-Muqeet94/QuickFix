using System.Collections.Generic;

namespace Fixit.Request_and_Responses.Cms
{
    public class CmsReq
    {
        public int id {get;set;}
        public string name {get;set;}
        public List<int> headings {get;set;}
     
    }
}