using System.Collections.Generic;
using Fixit.Models;

namespace Fixit.Request_and_Responses.Cms
{
    public class CmsRes
    {
        public int id {get;set;}
        public string name {get;set;}
        public virtual List<PageHeading> headings {get;set;}
    }
}