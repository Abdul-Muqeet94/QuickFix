using System.Collections.Generic;

namespace Fixit.Request_and_Responses.Headings
{
    public class HeadingsReq
    {
        public int id {get;set;}
        public string heading {get;set;}
        public string description {get;set;}
     
    }
}