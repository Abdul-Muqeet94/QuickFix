using System.Collections.Generic;
using Fixit.Models;

namespace Fixit.Request_and_Responses.Headings
{
    public class HeadingRes
    {
        public int id {get;set;}
        public string heading {get;set;}
        public string description {get;set;}
  
    }
}