namespace Fixit.Request_and_Responses.Employee
{
    public class EmployeeReq
    {
        public int id {get;set;}
        public string name {get;set;}
        public string email {get;set;}
         public string code {get;set;}
        public string contactNo {get;set;}
        public string emiratesId {get;set;}
        public string address {get;set;}
        public string nationality {get;set;}
        public int typeId {get;set;}
        public bool status {get;set;}
  
    }
}