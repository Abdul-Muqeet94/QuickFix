namespace Fixit.Request_and_Responses.Employee
{
    public class AssignEmployee
    {
        public int serviceId {get;set;}
        public int employeeId {get;set;}
    }
}