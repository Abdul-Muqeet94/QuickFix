using System;
using System.Collections.Generic;
using Fixit.Models;

namespace Fixit.Request_and_Responses.Shifts
{
    public class ShiftReq
    {      
        public int id {get;set;}
        public string name {get;set;}
        public DateTime sTime {get;set;}
        public DateTime eTime {get;set;}
        public DateTime sDate {get;set;}
        public DateTime eDate {get;set;}
        public int day {get;set;}
        public bool enable {get;set;}      
    }
}