using System.Collections.Generic;
using Fixit.Models;

namespace Fixit.Request_and_Responses.Feature
{
    public class FeatureReq
    {      
        public int id {get;set;}
        public string name {get;set;}
        public string description{get;set;}
    }
}