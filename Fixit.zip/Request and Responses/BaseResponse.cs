namespace Fixit.Request_and_Responses
{
    public class BaseResponse
    {
        public string developerMessage {get;set;}
        public int status {get;set;}
        public int id {get;set;} 
    }
}