(function () {
    var app = angular.module("homeModule", ['ngRoute']);


    app.controller("homeController", function ($scope, $http, $location, $rootScope) {
        $scope.message = $http.post('http://localhost:5000/api/service/view', 0).
            then(function (response) {
                $scope.services = response.data;
            });
        $scope.message = $http.post('http://localhost:5000/api/cms/viewbypage', "'index'").
            then(function (response) {
                $scope.cms = response.data;
                console.log($scope.cms);
            });

        $scope.places = ["Abu Dabi", "Ajman", "Dubai", "Sharjah"];
        $scope.$watch("selectedService", function (newValue, oldValue) {
            // your code goes here...
            if (newValue != oldValue) {

                var name = $scope.selectedService.originalObject.name;
				$rootScope.permService=$scope.selectedService.originalObject.id;
                if (name == "AC Service & Repair") {

                    $rootScope.service = $scope.selectedService.originalObject;
                    $rootScope.pageName = "AC Service & Repair";
                    $location.path('/ac-repair');
                    return;
                }
                else if (name == "CCTV Camera") {
                    $rootScope.service = $scope.selectedService.originalObject;
                    $rootScope.pageName = "CCTV Camera";
                    $location.path('/cctv-camera');
                    return;
                }
                else if (name == "Marble Tiles & Sanitary") {
                    $rootScope.service = $scope.selectedService.originalObject;
                    $rootScope.pageName = "Marble Tiles & Sanitary";
                    $location.path('/marble-tiles');
                }
                else if (name == "Electrician") {
                    $rootScope.service = $scope.selectedService.originalObject;
                    $rootScope.pageName = "Electrician";
                    $location.path('/electrician');
                }
                else if (name == "House Painters") {
                    $rootScope.service = $scope.selectedService.originalObject;
                    $rootScope.pageName = "House Painters";
                    $location.path('/painters');
                }
                else if (name == "Aluminum & Glass Work") {
                    $rootScope.service = $scope.selectedService.originalObject;
                    $rootScope.pageName = "Aluminum & Glass Work";
                    $location.path('/glass');
                }
                else if (name == "Carpenter") {
                    $rootScope.service = $scope.selectedService.originalObject;
                    $rootScope.pageName = "Carpenter";
                    $location.path('/carpenter');
                }
                else if (name == "Drilling & Hanging") {
                    $rootScope.service = $scope.selectedService.originalObject;
                    $rootScope.pageName = "Drilling & Hanging";
                    $location.path('/drilling');
                }
                else if (name == "Ceiling") {
                    $rootScope.service = $scope.selectedService.originalObject;
                    $rootScope.pageName = "Ceiling";
                    $location.path('/ceiling');
                }
                else if (name == "Plumbing") {
                    $rootScope.service = $scope.selectedService.originalObject;
                    $rootScope.pageName = "Plumbing";
                    $location.path('/plumbing');
                }
                else if (name == "Bathroom Deep Cleaning") {
                    $rootScope.service = $scope.selectedService.originalObject;
                    $rootScope.pageName = "Bathroom Deep Cleaning";
                    $location.path('/bathroom');
                }

            }
        });
        ////



        $scope.serviceClicked = function (name) {
            console.log(name);

            for (var i = 0; i < $scope.services.length; i++) {
                console.log($scope.services[i].name);
                if ($scope.services[i].name == name) {
					$rootScope.permService=$scope.services[i].id;
                    $rootScope.service = $scope.services[i];
                    break;

                }
            }

            if (name == 'AC Service & Repair') {
                $rootScope.pageName="AC Service & Repair";
                $location.path('/ac-repair');

            }
            else if (name == "CCTV Camera") {
                $rootScope.pageName="CCTV Camera";
                $location.path('/cctv-camera');
                return;
            }
            else if (name == "Marble Tiles & Sanitary") {
                $rootScope.pageName="Marble Tiles & Sanitary";
                $location.path('/marble-tiles');
                return;
            }
            else if (name == "Electrician") {
                $rootScope.pageName="Electrician";
                $location.path('/electrician');
                return;
            }
            else if (name == "House Painters") {
                $rootScope.pageName="House Painters";
                $location.path('/painters');
                return;
            }
            else if (name == "Aluminum & Glass Work") {
                $rootScope.pageName="Aluminum & Glass Work";
                $location.path('/glass');
                return;
            }
            else if (name == "Carpenter") {
                $rootScope.pageName="Carpenter";
                $location.path('/carpenter');
                return;
            }
            else if (name == "Drilling & Hanging") {
                $rootScope.pageName="Drilling & Hanging";
                $location.path('/drilling');
                return;
            }
            else if (name == "Ceiling") {
                $rootScope.pageName="Ceiling";
                $location.path('/ceiling');
                return;
            }
            else if (name == "Plumbing") {
                $rootScope.pageName="Plumbing";
                $location.path('/plumbing');
                return;
            }
            else if (name == "Bathroom Deep Cleaning") {
                $rootScope.pageName="Bathroom Deep Cleaning";
                $location.path('/bathroom');
                return;
            }


        }
    });

})();
