
(function () {
  var app = angular.module("formModule", ['ngRoute']);


app.controller("formController", function($scope,$http,$rootScope,$location,ModalService) {
  
  
          $scope.message = $http.post('http://localhost:5000/api/cms/viewbypage','"' + $rootScope.pageName + '"').
            then(function (response) {
                $scope.cms = response.data;
                console.log($scope.cms);
            });
$scope.BookNow= function()
{

  ModalService.showModal({
    templateUrl:'modal.html',
    controller: "featureController"
  }).then(function(modal) {

   modal.element.modal();
    modal.close.then(function(result) {
      console.log(result);
    });
  });


}

 });




////

  
})();
