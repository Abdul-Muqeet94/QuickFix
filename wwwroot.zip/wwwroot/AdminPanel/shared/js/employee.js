(function () {
    var app = angular.module('employeeModule', []);



    app.controller("addEmployee", function ($scope, $http, $log,$location) {
        $scope.emp={name:"",email:"",code:"",nationality:"",contactNo:"",emiratesId:"",address:"",typeId:[]}
         $http.post('http://localhost:5000/api/service/view', 0)
        .then(function (response) {
            $scope.services = response.data;
            console.log($scope.services);
        });

                $scope.save = function () {
                    $scope.emp.typeId=$scope.data.multipleSelect;
            $scope.message = $http.post('http://localhost:5000/api/employee/create', $scope.emp).
            then(function (response) {
              console.log(response.data);
              $location.path("/viewemployee");
               // $location.url('billers');

            });
        }
    });

     app.controller("updateEmployee", function ($scope, $http, $log,$rootScope,$location) {
         if($rootScope.empid==0)
         {
             $location.path("/viewemployee");
         }
          $http.post('http://localhost:5000/api/service/view', 0)
        .then(function (response) {
            $scope.services = response.data;
            console.log($scope.services);
        });
          $http.post('http://localhost:5000/api/employee/view', $rootScope.empid)
        .then(function (response) {
            $scope.employeeList = response.data;
            $scope.employee=$scope.employeeList[0];
            console.log($scope.employee);
        });
        $scope.update=function(){
            $scope.employee.typeId=$scope.data.multipleSelect;
            console.log($scope.employee);
            //api/employee/edit
             $http.post('http://localhost:5000/api/employee/edit', $scope.employee)
        .then(function (response) {
            $scope.data = response.data;
            console.log($scope.data);
            $location.path("/viewemployee");
        });
        };
     });


})();