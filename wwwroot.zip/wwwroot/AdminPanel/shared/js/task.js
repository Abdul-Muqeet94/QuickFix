(function () {
    var app = angular.module('taskModule', ['datatables', 'ngMap']);

    app.controller("addTask", function ($scope, $http, $log,$location) {

        $scope.emp = { name: "", email: "", code: "", nationality: "", contactNo: "", emiratesId: "", address: "", typeId: "" }
        $http.post('http://localhost:5000/api/service/view', 0)
            .then(function (response) {
                $scope.services = response.data;
                console.log($scope.services);

            });

        $scope.save = function () {

            console.log($scope.emp);
            $scope.message = $http.post('http://localhost:5000/api/employee/create', $scope.emp).
                then(function (response) {
                    console.log(response.data);
                        $location.path('/order');
                    // $location.url('billers');

                });
        }
    });


    //View Task

    app.controller("viewTask", function ($scope, DTOptionsBuilder, $http, $rootScope, $location) {

        $scope.tasks = {};
        // DataTables configurable options
        $scope.dtOptions = DTOptionsBuilder.newOptions()
            .withDisplayLength(10)
            .withOption('bLengthChange', false);

        $http.post('http://localhost:5000/api/task/toassignview', 0)
            .then(function (response) {
                $scope.tasks = response.data;
                console.log($scope.tasks);
            });

        $scope.delete = function (val) {
            //  console.log(index);

            $scope.message = $http.post('http://localhost:5000/api/task/delete', val).
                then(function (response) {
                    $scope.model = response.data;
                    console.log($scope.model);
                     $location.path('/order');
                });
        };
        $scope.checkEmp = function (val) {
            console.log($scope.tasks[val].assigned_employee.length);
            //$scope.tasks[val].selected_features.length
            if ($scope.tasks[val].assigned_employee.length > 0) {

                return false;
            }
            else {
                return true;
            }
        };

        $scope.assign = function (val) {
            //  console.log(index);

            $rootScope.taskId = val;
            $location.path("/orderassign");
        };




    });

    //End here
    app.controller("assignTask", function ($scope, $http, $log, $rootScope, NgMap, $location) {
        $scope.emailFilter={employee:0,email:"",service:0};
        $scope.sendingEmail = function (val) {
            return $rootScope.sendEmail = val;
        };
        $scope.sendingEmail(false);
        $scope.createTask = { task_id: "", service_employee: [] };
        $scope.service_employee = { serviceId: 0, employeeId: 0 };
        $scope.index = 0;

        NgMap.getMap().then(function (map) {
            console.log(map.getCenter());
            console.log('markers', map.markers);
            console.log('shapes', map.shapes);
        });


        $http.post('http://localhost:5000/api/task/viewforassign', $rootScope.taskId)
            .then(function (response) {
                $scope.tasksList = response.data;
                $scope.task = $scope.tasksList[0];
                console.log($scope.task);
            });


        $scope.save = function () {
            console.log($scope.index);
            if ($scope.service_employee.serviceId == 0) {
                $scope.service_employee.serviceId = $scope.task.selected_features[0].id;
            }
            $scope.createTask.task_id = $scope.task.id;
            $scope.createTask.service_employee.push($scope.service_employee);


            //
            console.log($scope.createTask);

            $scope.message = $http.post('http://localhost:5000/api/task/assignEmployee', $scope.createTask).
                then(function (response) {
                    console.log(response.data);
                });
            $scope.getHtml();
            $location.path("/order");
        };
         $scope.viewTask=function(val){
            $rootScope.taskId=val;
            $location.path('/vieworder');

        };

        $scope.getHtml = function () {
            $scope.sendingEmail(true);
            document.getElementById('dropDown').remove();
            document.getElementById('buttonSave').remove();
            var printContents = document.getElementById('getDiv').innerHTML;
            var pageContent = '<html><head><style> table {border-collapse:collapse;border-spacing:0;} th,td{border:none;text-align:left;padding:8px;} .th_bg{background-color:#f5f5f5;} .first_row tr th{font-size:15px; } .first_row tr{border-top: 1px solid #ddd;padding:15px 8px;} .first_row tr td{padding:12px 8px;color: #878787;font-weight: 300;font-size: 15px;} table {border-collapse: collapse; border-spacing: 0;} th, td {border: none;text-align: left;padding: 8px;} .th_bg {   background-color: #f5f5f5;} .first_row tr th{ font-size:15px; } .first_row tr{border-top: 1px solid #ddd;padding:15px 8px;} .first_row tr td{ padding:12px 8px;color: #878787;font-weight: 300;font-size: 15px;} </style></head><body>' + printContents + '</body></html>';
            console.log(pageContent);
            console.log($scope.service_employee);
            $scope.emailFilter.employee=$scope.service_employee.employeeId;
            $scope.emailFilter.service=$scope.task.id;
            $scope.emailFilter.email=pageContent;
            console.log($scope.emailFilter);
            $scope.message = $http.post('http://localhost:5000/api/task/sendemail', $scope.emailFilter).
                then(function (response) {
                    console.log(response.data);
                    $scope.sendingEmail(false);
                });
            //<link href="../shares/css/lib/font-awesome.min.css" rel="stylesheet"> <link href="../shared/css/style.css" rel="stylesheet"> <link href="../assets/css/lib/bootstrap.min.css" rel="stylesheet">
        };



    });


 app.controller("viewAssignTask", function ($scope, DTOptionsBuilder, $http, $rootScope, $location) {

        $scope.tasks = {};
        // DataTables configurable options
        $scope.dtOptions = DTOptionsBuilder.newOptions()
            .withDisplayLength(10)
            .withOption('bLengthChange', false);

        $http.post('http://localhost:5000/api/task/viewassigntask', 0)
            .then(function (response) {
                $scope.tasks = response.data;
                console.log($scope.tasks);
            });

        $scope.delete = function (val) {
            //  console.log(index);

            $scope.message = $http.post('http://localhost:5000/api/task/delete', val).
                then(function (response) {
                    $scope.model = response.data;
                    console.log($scope.model);
                     $location.path('/order');
                });
        };
         $scope.viewTask=function(val){
            $rootScope.taskId=val;
            $location.path('/vieworder');

        };
        $scope.checkEmp = function (val) {
            console.log($scope.tasks[val].assigned_employee.length);
            //$scope.tasks[val].selected_features.length
            if ($scope.tasks[val].assigned_employee.length > 0) {

                return false;
            }
            else {
                return true;
            }
        };

        $scope.assign = function (val) {
            //  console.log(index);

            $rootScope.taskId = val;
            $location.path("/orderassign");
        };




    });

})();