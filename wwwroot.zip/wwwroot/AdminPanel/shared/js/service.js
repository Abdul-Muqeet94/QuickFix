(function () {
    var app = angular.module('serviceModule', []);



    app.controller("addService", function ($scope, $http, $log,$location) {
        $scope.service={id:0,name:'',description:'',features:[]}
        $http.post('http://localhost:5000/api/feature/view', 0)
        .then(function (response) {
            $scope.features = response.data;
            console.log($scope.features);
        });
                $scope.save = function () {
            $scope.service.features=$scope.data.multipleSelect;
            console.log($scope.service);
            $scope.message = $http.post('http://localhost:5000/api/service/create', $scope.service).
            then(function (response) {
              console.log(response.data);
               $location.path('/viewservice');
            // $location.url('billers');

            });
        }
    });

     app.controller("updateService", function ($scope, $http, $log,$rootScope,$location) {

        $http.post('http://localhost:5000/api/feature/view', 0)
        .then(function (response) {
            $scope.features = response.data;
            console.log($scope.features);
        });

         $http.post('http://localhost:5000/api/service/view', $rootScope.serviceId)
        .then(function (response) {
            $scope.service = response.data[0];
            console.log($scope.service);
        });
		   $scope.getFeatureIndex=function(val){
       if($scope.service.feature.length>val)
       {
           return val;
       } 
       else
       {
         return $scope.service.feature.length-1;
       }
    };
        $scope.update=function()
        {
             $scope.service.features=$scope.data.multipleSelect;
            console.log($scope.service);
  $http.post('http://localhost:5000/api/service/edit', $scope.service)
        .then(function (response) {
            $scope.result = response.data;
            console.log($scope.result);
           $location.path('/viewservice');
        });
        };
     });


})();