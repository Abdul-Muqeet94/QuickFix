
(function () {
    var app = angular.module("mainModule", ['ngRoute','angularjs-datetime-picker','reportModule','cmsModule', 'taskModule', 'featureModule', 'datatableModule', 'serviceModule', 'ng-weekday-selector', 'employeeModule']);

    app.run(function ($rootScope) {
        $rootScope.taskId = 0;
        $rootScope.shift = {};
        $rootScope.empid = 0;
        $rootScope.featureId = 0;
        $rootScope.serviceId = 0;
        $rootScope.sendEmail = false;
        $rootScope.cmsId=0;
    });

    app.config(function ($routeProvider) {
        $routeProvider
            .when("/shift", {
                controller: "cshiftController",
                templateUrl: "../views/cshift.html"
            })
            .when("/viewshift", {
                controller: "vshiftController",
                templateUrl: "../views/vshift.html"
            })
            .when("/addemployee", {
                controller: "addEmployee",
                templateUrl: "../views/addemployee.html"
            })

            .when("/viewemployee", {
                controller: "datatableController",
                templateUrl: "../views/viewemployee.html"
            })
            .when("/updateEmployee", {
                controller: "updateEmployee",
                templateUrl: "../views/updateEmployee.html"
            })

            .when("/addservice", {
                controller: "addService",
                templateUrl: "../views/addServices.html"
            })

            .when("/viewservice", {
                controller: "serviceController",
                templateUrl: "../views/viewServices.html"
            })
            .when("/addfeatures", {
                controller: "addFeature",
                templateUrl: "../views/createFeatures.html"
            })
            .when("/viewfeatures", {
                //featureController
                controller: "featureController",
                templateUrl: "../views/ViewFeatures.html"
            })
            .when("/order", {
                //viewTask
                controller: "viewTask",
                templateUrl: "../views/orders.html"
            })
            .when("/updateFeature", {
                controller: "updateFeature",
                templateUrl: "../views/updateFeatures.html"
            })
            .when("/orderassign", {
                controller: "assignTask",
                templateUrl: "../views/ordersassign.html"
            }).when("/updateService", {
                controller: "updateService",
                templateUrl: "../views/updateService.html"
            }).when("/taskService", {
                controller: "updateService",
                templateUrl: "../views/updateService.html"
            }).when("/manager", {
                controller: "manageCms",
                templateUrl: "../views/manage.html"
            }).when("/viewcms", {
                controller: "viewcms",
                templateUrl: "../views/viewcms.html"
            })
            .when("/viewassignorder", {
                controller: "viewAssignTask",
                templateUrl: "../views/viewassignorders.html"
            }).when("/report", {
                controller: "searchReport",
                templateUrl: "../views/Reports.html"
            }).when("/vieworder", {
                controller: "vieworder",
                templateUrl: "../views/vieworder.html"
            }).when("/updatecms", {
                controller: "updateCms",
                templateUrl: "../views/updatecms.html"
            })

///
            //report  vieworder
//viewcms
            //manager
        //updateService
    });













    app.controller("cshiftController", function ($scope, $http, $rootScope) {

        console.log($rootScope.shift);

        console.log($rootScope.shift.day);

        $scope.hello = function () {
            console.log($rootScope.shift.day);
            for (var i = 0; i < $scope.shift.day.length; i++) {
                $scope.days[$scope.shift.day[i] - 1].isSelected = true;
            }
        }

        $scope.addShift = function () {
            $scope.shift.sTime = document.getElementById('stime').value;
            $scope.shift.eTime = document.getElementById('etime').value;
            $scope.shift.days = $scope.days;

            console.log($scope.shift);
            if ($scope.shift.id == null) {
                $scope.message = $http.post('http://localhost:5000/api/shift/create', $scope.shift).
                    then(function (response) {
                        console.log(response.data);
                    });
                return;
            }
            else {
                console.log("inside the edit api");

                delete $scope.shift.day;


                console.log($scope.shift);
                $scope.message = $http.post('http://localhost:5000/api/shift/edit', $scope.shift).
                    then(function (response) {
                        console.log(response.data);
                    });
            }
        }
    });
    app.controller("vshiftController", function ($scope, $http, $rootScope, $location) {

        $scope.message = $http.post('http://localhost:5000/api/shift/view', 0).
            then(function (response) {
                $scope.shifts = response.data;
                $rootScope.shifts = response.data;
                console.log($rootScope.shifts);
            });
        $scope.delete = function (id) {
            $scope.message = $http.post('http://localhost:5000/api/shift/delete', id).
                then(function (response) {
                    var row = document.getElementById(id);
                    row.parentNode.removeChild(row);
                });
        }

        $scope.update = function (id) {
            for (var i = 0; i < $rootScope.shifts.length; i++) {
                if ($rootScope.shifts[i].id == id) {
                    $rootScope.shift = $rootScope.shifts[i];
                    $location.path("/shift");
                    return;
                }
            }
            // $scope.message = $http.post('http://localhost:5000/api/shift/view',id).
            //       then(function (response){
            //           $rootScope.shift=response.data[0];
            //          console.log($rootScope.shift);
        }
    });

    ////


})();
