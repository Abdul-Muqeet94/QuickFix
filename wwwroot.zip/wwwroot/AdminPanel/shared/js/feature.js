(function () {
    var app = angular.module('featureModule',[]);



    app.controller("addFeature", function ($scope, $http, $log,$location) {
        
                $scope.save = function () {
            
            console.log($scope.feature);
            $scope.message = $http.post('http://localhost:5000/api/feature/create', $scope.feature).
            then(function (response) {
              console.log(response.data);
              $location.path('/viewfeatures');
               // $location.url('billers');

            });
        }
    });
 app.controller("updateFeature", function ($scope, $http, $log,$rootScope,$location) {

     $scope.message = $http.post('http://localhost:5000/api/feature/view', $rootScope.featureId).
            then(function (response) {
                $scope.feature=response.data[0];
                console.log($scope.feature);
                // 
            });
            $scope.update=function(){
                 $scope.message = $http.post('http://localhost:5000/api/feature/edit', $scope.feature).
            then(function (response) {
                $scope.feature=response.data;
                console.log($scope.feature);
                $location.path('/viewfeatures');
                // 
            });
            };
    
 });

})();